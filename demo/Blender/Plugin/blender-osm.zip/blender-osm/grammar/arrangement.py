

# constants for arrangement
Vertical = 1
Horizontal = 2
# <Layers> means that the items located like layers in graphics editor (i.e. one over another)
Layers = 3