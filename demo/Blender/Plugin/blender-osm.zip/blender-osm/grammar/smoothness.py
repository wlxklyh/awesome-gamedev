

# constants for smoothness of building surfaces
Smooth = 1
Flat = 2
Horizontal = 3
Side = 4
All = 5