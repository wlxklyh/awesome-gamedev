

# constants for symmetry
MiddleOfLast = 1
RightmostOfLast = 2