
RoofShapes = {
    "flat": 1,
    "gabled": 1,
    #"hipped": 1,
    "pyramidal": 1,
    #"skillion": 1,
    "round": 1,
    "dome": 1,
    "half-dome": 1,
    "onion": 1,
    "gambrel": 1,
    "saltbox": 1
}


CladdingMaterials = {
    "brick": 1,
    "plaster": 1,
    "glass": 1,
    "concrete": 1,
    "gravel": 1,
    "metal": 1,
    "roof_tiles": 1
}


RoofOrientation = {
    "along",
    "across"
}