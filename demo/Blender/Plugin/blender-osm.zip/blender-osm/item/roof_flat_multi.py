from .roof_flat import RoofFlat


class RoofFlatMulti(RoofFlat):
    pass