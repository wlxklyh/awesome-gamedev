from . import Item


class Chimney(Item):
    pass